#ifndef _BD_PARSER_JAVASCRIPT_H
#define _BD_PARSER_JAVASCRIPT_H

#include "BDString.h"

class CParseJavaScriptNode : private CParseMarkupNode {
	public:
	private:
		};


#endif	// _BD_PARSER_JAVASCRIPT_H
